let LoginForm = document.querySelector('.login-form');

document.querySelector('#login-btn').onclick = () => {
    LoginForm.classList.toggle('active');
}

let navbar = document.querySelector('.navbar');

document.querySelector('#menu-btn').onclick = () => {
    navbar.classList.toggle('active');
    LoginForm.classList.remove('active'); // Fixed variable name here
}

window.onscroll = () => {
    LoginForm.classList.remove('active');
    navbar.classList.remove('active');
}
