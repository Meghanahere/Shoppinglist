// JavaScript to handle cart functionality

const products = [
    {
        id: 1,
        name: 'Carrot',
        price: 10.99,
        image: '1.jpg',
    },
    {
        id: 2,
        name: 'Broccoli',
        price: 8.49,
        image: '2.jpg',
    },
    {
        id: 3,
        name: 'Onion',
        price: 12.99,
        image: '3.jpg',
    },
    {
        id: 4,
        name: 'Beans',
        price: 6.99,
        image: '4.jpg',
    },
    {
        id: 5,
        name: 'Capsicum',
        price: 9.99,
        image: '5.jpg',
    },
    {
        id: 6,
        name: 'Tomato',
        price: 14.99,
        image: '6.jpg',
    },
];

const cart = [];

// Function to update the cart display
function updateCart() {
    const cartList = document.getElementById('cart-list');
    const totalElement = document.querySelector('.total');
    let total = 0;

    // Clear the cart display
    cartList.innerHTML = '';

    // Populate the cart display with items
    cart.forEach((item) => {
        const listItem = document.createElement('li');
        listItem.classList.add('cart-item');
        listItem.innerHTML = `
            <img src="${item.image}" alt="${item.name}">
            <p>${item.name}</p>
            <p>Rs ${item.price.toFixed(2)}</p>
            <button class="remove-item" data-id="${item.id}" >Remove</button>
        `;
        cartList.appendChild(listItem);
        total += item.price;
    });

    // Update the total
    totalElement.textContent = `Total:Rs ${total.toFixed(2)}`;
}

// Function to handle adding items to the cart
function addToCart(productId) {
    const product = products.find((item) => item.id === productId);
    if (product) {
        cart.push({ ...product });
        updateCart();
    }
}

// Function to handle removing items from the cart
function removeFromCart(productId) {
    const index = cart.findIndex((item) => item.id === productId);
    if (index !== -1) {
        cart.splice(index, 1);
        updateCart();
    }
}

// Event delegation for "Add to Cart" and "Remove" buttons
document.addEventListener('click', (e) => {
    if (e.target.classList.contains('add-to-cart')) {
        const productId = parseInt(e.target.parentElement.getAttribute('data-id'));
        addToCart(productId);
    }
    if (e.target.classList.contains('remove-item')) {
        const productId = parseInt(e.target.getAttribute('data-id'));
        removeFromCart(productId);
    }
});

// Initialize the cart display
updateCart();
